# MinJob 크롤 콘솔 (데모)

한국 교회 **청빙(교역자 채용) 공고**를 게시판에서 수집하는 크롤러 데모.
운영자가 **소스를 고르고 → 크롤을 실행하고 → raw 결과를 확인하고 → 리뷰 큐에 저장**하는 콘솔이다.

> 이 데모의 본체는 **raw 추출**(원문+메타를 손실 없이 가져오기)이다. 구조화(AI)·DB 삽입은
> "저장된 raw를 나중에 검수해서" 하는 별도 단계이며, 여기서는 **Gemini 구조화 "미리보기"** 만 옵션으로 보여준다.

## 구성 (2파트)

```
crawler/   Python  — raw 추출 엔진 (소스별 어댑터, 원문+메타만 뽑음)
admin/     Next.js — 운영자 콘솔 (소스 선택·크롤·raw 표시·저장·구조화 미리보기)
data/      리뷰 큐 (staging.json) — admin이 저장, gitignore
```
어드민이 크롤할 때 파이썬 크롤러를 CLI로 호출한다(`python -m crawler <source> --limit N`).

## 빠른 시작

요구: **Python 3.10+**, **Node 20+**

```bash
./setup.sh                       # .venv + 크롤러 의존성 + admin 의존성 + admin/.env
source .venv/bin/activate        # 크롤러(python)가 이 venv를 쓰도록
cd admin && npm run dev          # http://localhost:3000  (점유 중이면 자동 3001+)
```

브라우저에서: **소스 선택 → 크롤 실행 → raw 카드 확인 → 저장**. 저장한 건 상단 "저장된 데이터"에서 확인.

## 크롤러만 단독으로 (터미널)

```bash
source .venv/bin/activate
python -m crawler --list-sources            # 등록 소스
python -m crawler ytus --limit 3            # 영남신대 최근 3건 raw JSON
python -m crawler ytus --limit 3 --offline  # 네트워크 없이 샘플 HTML로
```

## 수집 소스 (데모 4종, 전부 공개 게시판)

| key | 게시판 | 교단 | 비고 |
|---|---|---|---|
| `ytus` | 영남신학대 취업/초빙 | 예장통합 | 매우 활발 |
| `kehc` | 기독교대한성결교회 총회 구인 | 성결교 | 매우 활발 |
| `koreabaptist` | 기독교한국침례회 목회자청빙 | 침례교 | 활발 |
| `prok` | 한국기독교장로회 교역자 청빙 | 기타(기장) | **목록만** — 상세는 로그인 필요라 raw_text 비고 배지 표시 |

> 어댑터는 `crawler/adapters/`에 1소스=1파일. `koreabaptist`·`prok`는 같은 게시판 솔루션이라
> 공용 베이스(`dimode_board.py`)를 공유한다. 새 소스는 어댑터 파일 하나 + registry 등록으로 추가.

## 구조화 미리보기 (Gemini, 선택)

각 raw 카드의 "구조화 미리보기" 버튼 → Vertex AI **Gemini 2.5 Flash**로 원문을 교회명·교단·직분·부서·
고용형태·사례비(원문 보존)·마감·요약으로 구조화해 보여준다. **저장/DB와 무관한 미리보기**다.

- `admin/.env`에 Vertex 서비스계정 값을 채워야 동작한다(없으면 버튼이 에러를 표시할 뿐 raw 흐름은 정상).
- 확인된 사용 가능 모델: `gemini-2.5-flash`, `gemini-2.5-flash-lite` (env `VERTEX_MODEL`), location `global`.

## 데이터 형태 (raw)

크롤러 출력 = `RawPosting` 배열. 주요 필드:
`source_key · board_name · post_url · external_id · title · author · posted_at · view_count ·
raw_text(본문 원문) · attachments · links · extra · default_denomination · crawl_mode · fetched_at`

저장 시 `review_status: "PENDING"` + `saved_at`이 붙어 `data/staging.json`에 쌓인다(dedup: source_key+external_id).

## 실서비스로 갈 때 (데모 → 프로덕션)

- 저장소 `data/staging.json` → Supabase 스테이징 테이블(store 계층만 교체).
- 어드민 수동 실행 → 스케줄 크롤러(GitHub Actions cron)가 같은 큐에 자동 적재, 어드민은 검수 전용.
- 로그인 게시판(prok 상세 등)은 계정·법률검토 후 인증 크롤.

## 참고

- 데모용 프로토타입이다(파일 저장 동시성·토스트 등은 단일 운영자 전제로 단순화).
- 크롤은 공개 게시판 대상이며, robots/rate-limit·개인정보 미추출 등은 실서비스에서 강화한다.
