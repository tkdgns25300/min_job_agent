#!/usr/bin/env bash
# minjob-crawler-demo 셋업: Python 크롤러 venv + Next.js 어드민 의존성
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "[1/3] Python 가상환경(.venv) 생성 + 크롤러 의존성 설치"
python3 -m venv .venv
./.venv/bin/pip install --quiet --upgrade pip
./.venv/bin/pip install --quiet -r crawler/requirements.txt

echo "[2/3] 어드민(Next.js) 의존성 설치"
( cd admin && npm install --silent )

echo "[3/3] admin/.env 준비"
if [ ! -f admin/.env ]; then
  cp admin/.env.example admin/.env
  echo "  -> admin/.env 생성됨. Gemini 구조화를 쓰려면 vertex_ai.txt 값을 채우세요(선택)."
else
  echo "  -> admin/.env 이미 있음 (건너뜀)."
fi

cat <<'MSG'

셋업 완료. 실행:
  source .venv/bin/activate          # 크롤러(python)가 이 venv를 쓰도록
  cd admin && npm run dev            # http://localhost:3000 (점유 중이면 3001+)

그다음 브라우저에서: 소스 선택 → 크롤 실행 → raw 확인 → 저장.
MSG
