"""HTTP fetch 계층: 재시도 + 한국 사이트 인코딩(EUC-KR 등) 대응."""

from __future__ import annotations

import logging
import re
import time

import httpx

logger = logging.getLogger(__name__)

USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)
TIMEOUT_SECONDS = 10.0
MAX_ATTEMPTS = 3
RETRY_BACKOFF_SECONDS = 1.0

_META_CHARSET_PATTERN = re.compile(rb"charset=[\"']?([\w-]+)", re.IGNORECASE)
# 한국 교회/학교 사이트에서 흔한 레거시 인코딩 대비 순서
_FALLBACK_ENCODINGS = ("utf-8", "cp949")

# TODO(next stage): robots.txt 준수 체크를 여기(fetch 경계)에 추가한다.


class FetchError(Exception):
    """재시도 후에도 페이지를 가져오지 못했을 때."""


def fetch_html(url: str) -> str:
    """URL의 HTML을 문자열로 반환. 실패 시 FetchError."""
    last_error: Exception | None = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = httpx.get(
                url,
                headers={"User-Agent": USER_AGENT},
                timeout=TIMEOUT_SECONDS,
                follow_redirects=True,
            )
            response.raise_for_status()
            return _decode_body(response)
        except httpx.HTTPError as error:
            last_error = error
            logger.warning("fetch 실패 (%d/%d) %s: %s", attempt, MAX_ATTEMPTS, url, error)
            if attempt < MAX_ATTEMPTS:
                time.sleep(RETRY_BACKOFF_SECONDS * attempt)
    raise FetchError(f"failed to fetch {url}") from last_error


def _decode_body(response: httpx.Response) -> str:
    """헤더 charset → meta charset → utf-8/cp949 순으로 디코딩을 시도한다."""
    header_charset = response.charset_encoding
    if header_charset:
        try:
            return response.content.decode(header_charset)
        except (UnicodeDecodeError, LookupError):
            logger.warning("헤더 charset(%s) 디코딩 실패, 폴백 시도", header_charset)

    candidates = [_sniff_meta_charset(response.content), *_FALLBACK_ENCODINGS]
    for encoding in filter(None, candidates):
        try:
            return response.content.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return response.content.decode("utf-8", errors="replace")


def _sniff_meta_charset(body: bytes) -> str | None:
    match = _META_CHARSET_PATTERN.search(body[:4096])
    return match.group(1).decode("ascii", errors="ignore") if match else None
