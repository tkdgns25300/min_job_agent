"""CLI 진입점.

사용법:
    python -m crawler <source_key> [--limit N] [--offline]
    python -m crawler --list-sources [--json]
"""

from __future__ import annotations

import argparse
import json
import logging
import sys

from crawler.adapters.registry import create_adapter, list_source_keys, list_sources_meta
from crawler.models import postings_to_json

DEFAULT_LIMIT = 10


def main() -> int:
    args = _parse_args()
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(levelname)s %(name)s: %(message)s")

    if args.list_sources:
        if args.json:
            print(json.dumps(list_sources_meta(), ensure_ascii=False, indent=2))
        else:
            for key in list_source_keys():
                print(key)
        return 0

    if args.source_key is None:
        print("source_key가 필요합니다. --list-sources로 확인하세요.", file=sys.stderr)
        return 2

    try:
        adapter = create_adapter(args.source_key, offline=args.offline)
    except KeyError as error:
        print(str(error), file=sys.stderr)
        return 2

    refs = adapter.list_postings(limit=args.limit)
    postings = [adapter.fetch_posting(ref) for ref in refs]
    print(postings_to_json(postings))
    return 0


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="crawler", description="교회 청빙 공고 raw 수집기")
    parser.add_argument("source_key", nargs="?", help="수집할 소스 키 (예: ytus)")
    parser.add_argument("--limit", type=int, default=DEFAULT_LIMIT, help="최대 수집 건수")
    parser.add_argument("--offline", action="store_true", help="라이브 fetch 없이 samples/ HTML만 사용")
    parser.add_argument("--list-sources", action="store_true", help="등록된 소스 목록 출력")
    parser.add_argument("--json", action="store_true", help="--list-sources를 JSON 메타로 출력")
    return parser.parse_args()


if __name__ == "__main__":
    sys.exit(main())
