"""크롤러가 산출하는 raw 데이터 모델.

구조화(enum 매핑, 필드 추출)는 이 단계에서 하지 않는다 — 원문 보존이 목적.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field


@dataclass
class PostingRef:
    """목록 페이지에서 얻는 글 1건의 참조 정보."""

    external_id: str
    title: str
    post_url: str
    author: str | None = None
    posted_at: str | None = None  # "YYYY-MM-DD"
    view_count: int | None = None
    extra: dict[str, str] = field(default_factory=dict)


@dataclass
class RawPosting:
    """상세 페이지까지 읽어 완성한 공고 1건의 raw 결과."""

    source_key: str
    board_name: str
    list_url: str
    post_url: str
    external_id: str
    title: str
    author: str | None
    posted_at: str | None  # "YYYY-MM-DD"
    view_count: int | None
    raw_text: str
    attachments: list[dict[str, str]]  # [{name, url}]
    links: list[str]
    extra: dict[str, str]
    default_denomination: str
    crawl_mode: str
    fetched_at: str  # ISO8601


def postings_to_json(postings: list[RawPosting]) -> str:
    return json.dumps([asdict(p) for p in postings], ensure_ascii=False, indent=2)
