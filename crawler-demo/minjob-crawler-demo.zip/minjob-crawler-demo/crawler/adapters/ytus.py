"""영남신학대학교 취업/초빙게시판(ytus) 어댑터.

페이지 구조 (2026-07 확인, UTF-8):
- 목록: tr > td.num / td.title a[data-article_idx] / td.author / td.rdate / td.rnum
  (공지 행은 td.num이 숫자 대신 이미지라 텍스트가 비어 있음 → 제외)
- 상세: div.boardViewContainer > .viewTitle / tr.view-info .info-cont(작성자·등록일·조회수)
  / div.boardViewContent(본문) / div.view-file a(첨부)
"""

from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from bs4.element import Tag

from crawler.adapters.base import SourceAdapter
from crawler.adapters.common import SAMPLES_DIR, extract_body_text, load_html, parse_int
from crawler.models import PostingRef, RawPosting

BASE_URL = "https://www.ytus.ac.kr"
LIST_URL = f"{BASE_URL}/board/list/trXXR"

SAMPLE_LIST_FILE = SAMPLES_DIR / "ytus_list.html"
SAMPLE_DETAIL_FILE = SAMPLES_DIR / "ytus_detail.html"

LIST_ROW_SELECTOR = "table tbody tr"
LIST_TITLE_LINK_SELECTOR = "td.title a[data-article_idx]"
DETAIL_CONTAINER_SELECTOR = "div.boardViewContainer"
DETAIL_TITLE_SELECTOR = "div.viewTitle"
DETAIL_INFO_SELECTOR = "tr.view-info div.info-cont > div"
DETAIL_BODY_SELECTOR = "div.boardViewContent"
DETAIL_ATTACHMENT_SELECTOR = "div.view-file a[href]"

_HTML_PARSER = "lxml"


class YtusAdapter(SourceAdapter):
    source_key = "ytus"
    board_name = "영남신학대학교 취업/초빙게시판"
    default_denomination = "TONGHAP"
    crawl_mode = "A"

    def __init__(self, offline: bool = False) -> None:
        # offline=True면 라이브 fetch 없이 samples/의 저장된 HTML만 사용
        self._offline = offline

    def list_postings(self, limit: int) -> list[PostingRef]:
        html = load_html(LIST_URL, SAMPLE_LIST_FILE, self._offline)
        soup = BeautifulSoup(html, _HTML_PARSER)
        refs = [
            ref
            for row in soup.select(LIST_ROW_SELECTOR)
            if (ref := self._parse_list_row(row)) is not None
        ]
        return refs[:limit]

    def fetch_posting(self, ref: PostingRef) -> RawPosting:
        html = load_html(ref.post_url, SAMPLE_DETAIL_FILE, self._offline)
        return self._parse_detail(html, ref)

    # --- 목록 파싱 ---

    def _parse_list_row(self, row: Tag) -> PostingRef | None:
        link = row.select_one(LIST_TITLE_LINK_SELECTOR)
        num_cell = row.select_one("td.num")
        if link is None or num_cell is None:
            return None
        list_num = num_cell.get_text(strip=True)
        if not list_num.isdigit():
            return None  # 공지(고정) 행 — 청빙 공고가 아님

        return PostingRef(
            external_id=str(link["data-article_idx"]),
            title=link.get_text(strip=True),
            post_url=urljoin(BASE_URL, str(link["href"])),
            author=_cell_text(row, "td.author"),
            posted_at=_cell_text(row, "td.rdate"),
            view_count=parse_int(_cell_text(row, "td.rnum")),
            extra={"list_num": list_num},
        )

    # --- 상세 파싱 ---

    def _parse_detail(self, html: str, ref: PostingRef) -> RawPosting:
        soup = BeautifulSoup(html, _HTML_PARSER)
        container = soup.select_one(DETAIL_CONTAINER_SELECTOR)
        if container is None:
            raise ValueError(f"detail container not found: {ref.post_url}")

        info = self._parse_view_info(container)
        body = container.select_one(DETAIL_BODY_SELECTOR)
        title_node = container.select_one(DETAIL_TITLE_SELECTOR)

        return RawPosting(
            source_key=self.source_key,
            board_name=self.board_name,
            list_url=LIST_URL,
            post_url=ref.post_url,
            external_id=ref.external_id,
            title=title_node.get_text(strip=True) if title_node else ref.title,
            author=info.get("작성자") or ref.author,
            posted_at=info.get("등록일") or ref.posted_at,
            view_count=parse_int(info.get("조회수")) or ref.view_count,
            raw_text=extract_body_text(body) if body else "",
            attachments=self._parse_attachments(container),
            links=self._parse_body_links(body),
            extra=dict(ref.extra),
            default_denomination=self.default_denomination,
            crawl_mode=self.crawl_mode,
            fetched_at=datetime.now(timezone.utc).isoformat(),
        )

    def _parse_view_info(self, container: Tag) -> dict[str, str]:
        """작성자/등록일/조회수 블록을 {라벨: 값}으로 반환."""
        info: dict[str, str] = {}
        for block in container.select(DETAIL_INFO_SELECTOR):
            label = block.find("b")
            value = block.find("p")
            if label and value:
                info[label.get_text(strip=True)] = value.get_text(strip=True)
        return info

    def _parse_attachments(self, container: Tag) -> list[dict[str, str]]:
        return [
            {
                "name": link.get_text(strip=True),
                "url": urljoin(BASE_URL, str(link["href"])),
            }
            for link in container.select(DETAIL_ATTACHMENT_SELECTOR)
        ]

    def _parse_body_links(self, body: Tag | None) -> list[str]:
        if body is None:
            return []
        return [urljoin(BASE_URL, str(link["href"])) for link in body.select("a[href]")]


def _cell_text(row: Tag, selector: str) -> str | None:
    cell = row.select_one(selector)
    text = cell.get_text(strip=True) if cell else ""
    return text or None
