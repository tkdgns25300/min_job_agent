"""기독교대한성결교회 총회 '성결광장 구인' 게시판 어댑터 (CodeIgniter 계열).

페이지 구조 (2026-07 확인, UTF-8):
- 목록: div.board_wrap table tr — 셀 순서 [번호, 상태, 분류, 제목, 작성자, 날짜, 조회]
  (공지 행은 번호 셀이 "공지", 링크에 notice_title 클래스 → 제외)
  제목 링크는 href="javascript:read_post(ID)" → 상세 URL /home/recruit/read_post/{ID}
  날짜는 "YY.MM.DD" 축약형 → "20YY-MM-DD"로 정규화
- 상세: 첫 번째 table.table = 메타(작성자/조회수/작성일/분류/상태 라벨-값 쌍),
  두 번째 table.table = 제목 행 + 본문(div#data_content), 첨부는 #attachFileList a
- 본문 이메일은 Cloudflare가 data-cfemail로 난독화 → 원문 보존을 위해 복호한다
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from bs4.element import Tag

from crawler.adapters.base import SourceAdapter
from crawler.adapters.common import SAMPLES_DIR, extract_body_text, load_html, parse_int
from crawler.models import PostingRef, RawPosting

logger = logging.getLogger(__name__)

BASE_URL = "http://www.kehc.org"
LIST_URL = f"{BASE_URL}/home/recruit/view_list/page/0"
DETAIL_URL_TEMPLATE = f"{BASE_URL}/home/recruit/read_post/{{external_id}}"

SAMPLE_LIST_FILE = SAMPLES_DIR / "kehc_list.html"
SAMPLE_DETAIL_FILE = SAMPLES_DIR / "kehc_detail.html"

LIST_ROW_SELECTOR = "div.board_wrap table tr"
DETAIL_META_TABLE_SELECTOR = "table.table"
DETAIL_BODY_SELECTOR = "div#data_content"
DETAIL_ATTACHMENT_SELECTOR = "#attachFileList a[href]"
CF_EMAIL_SELECTOR = "a.__cf_email__[data-cfemail]"

# 목록 셀 순서: 번호, 상태, 분류, 제목, 작성자, 날짜, 조회
LIST_COLUMN_COUNT = 7

_READ_POST_ID_PATTERN = re.compile(r"read_post\((\d+)\)")
_SHORT_DATE_PATTERN = re.compile(r"^(\d{2})\.(\d{2})\.(\d{2})$")

_HTML_PARSER = "lxml"


class KehcAdapter(SourceAdapter):
    source_key = "kehc"
    board_name = "기독교대한성결교회 성결광장 구인"
    default_denomination = "SEONGGYUL"
    crawl_mode = "A"

    def __init__(self, offline: bool = False) -> None:
        self._offline = offline

    def list_postings(self, limit: int) -> list[PostingRef]:
        html = load_html(LIST_URL, SAMPLE_LIST_FILE, self._offline)
        soup = BeautifulSoup(html, _HTML_PARSER)
        refs = [
            ref
            for row in soup.select(LIST_ROW_SELECTOR)
            if (ref := self._parse_list_row(row)) is not None
        ]
        return refs[:limit]

    def fetch_posting(self, ref: PostingRef) -> RawPosting:
        html = load_html(ref.post_url, SAMPLE_DETAIL_FILE, self._offline)
        return self._parse_detail(html, ref)

    # --- 목록 파싱 ---

    def _parse_list_row(self, row: Tag) -> PostingRef | None:
        cells = row.find_all("td", recursive=False)
        if len(cells) != LIST_COLUMN_COUNT:
            return None  # 헤더(th) 행 등
        number_cell, status_cell, category_cell, title_cell, author_cell, date_cell, view_cell = cells

        list_num = number_cell.get_text(strip=True)
        if not list_num.isdigit():
            return None  # 공지(고정) 행 — 청빙 공고가 아님

        link = title_cell.find("a", href=True)
        if link is None:
            return None
        id_match = _READ_POST_ID_PATTERN.search(str(link["href"]))
        if id_match is None:
            return None  # 비밀글 등 read_post 링크가 없는 행

        external_id = id_match.group(1)
        return PostingRef(
            external_id=external_id,
            title=link.get_text(strip=True),
            post_url=DETAIL_URL_TEMPLATE.format(external_id=external_id),
            author=author_cell.get_text(strip=True) or None,
            posted_at=_normalize_short_date(date_cell.get_text(strip=True)),
            view_count=parse_int(view_cell.get_text(strip=True)),
            extra={
                "list_num": list_num,
                "status": status_cell.get_text(strip=True),
                "category": category_cell.get_text(strip=True),
            },
        )

    # --- 상세 파싱 ---

    def _parse_detail(self, html: str, ref: PostingRef) -> RawPosting:
        soup = BeautifulSoup(html, _HTML_PARSER)
        _decode_cloudflare_emails(soup)

        body = soup.select_one(DETAIL_BODY_SELECTOR)
        if body is None:
            raise ValueError(f"detail body not found: {ref.post_url}")

        meta = self._parse_meta_table(soup)
        posted_at_full = meta.get("작성일", "")

        return RawPosting(
            source_key=self.source_key,
            board_name=self.board_name,
            list_url=LIST_URL,
            post_url=ref.post_url,
            external_id=ref.external_id,
            title=self._parse_title(body) or ref.title,
            author=meta.get("작성자") or ref.author,
            posted_at=posted_at_full.split()[0] if posted_at_full else ref.posted_at,
            view_count=parse_int(meta.get("조회수")) or ref.view_count,
            raw_text=extract_body_text(body),
            attachments=self._parse_attachments(soup),
            links=self._parse_body_links(body),
            extra=dict(ref.extra),
            default_denomination=self.default_denomination,
            crawl_mode=self.crawl_mode,
            fetched_at=datetime.now(timezone.utc).isoformat(),
        )

    def _parse_meta_table(self, soup: BeautifulSoup) -> dict[str, str]:
        """첫 table.table의 라벨-값 쌍(작성자/조회수/작성일/분류/상태)을 반환."""
        meta_table = soup.select_one(DETAIL_META_TABLE_SELECTOR)
        if meta_table is None:
            return {}
        info: dict[str, str] = {}
        for tr in meta_table.find_all("tr"):
            cells = tr.find_all("td")
            for label_cell, value_cell in zip(cells[::2], cells[1::2]):
                label = label_cell.get_text(strip=True)
                if label:
                    info[label] = value_cell.get_text(strip=True)
        return info

    def _parse_title(self, body: Tag) -> str | None:
        # 제목은 본문(#data_content)이 속한 두 번째 table.table의 첫 행에 있다
        content_table = body.find_parent("table")
        first_row = content_table.find("tr") if content_table else None
        title_cell = first_row.find("td") if first_row else None
        text = title_cell.get_text(strip=True) if title_cell else ""
        return text or None

    def _parse_attachments(self, soup: BeautifulSoup) -> list[dict[str, str]]:
        return [
            {"name": link.get_text(strip=True), "url": urljoin(BASE_URL, str(link["href"]))}
            for link in soup.select(DETAIL_ATTACHMENT_SELECTOR)
        ]

    def _parse_body_links(self, body: Tag) -> list[str]:
        return [
            urljoin(BASE_URL, str(link["href"]))
            for link in body.select("a[href]")
            if "email-protection" not in str(link["href"])  # 복호된 이메일 자리표시 링크 제외
        ]


def _normalize_short_date(text: str) -> str | None:
    match = _SHORT_DATE_PATTERN.match(text)
    if match is None:
        return text or None
    year, month, day = match.groups()
    return f"20{year}-{month}-{day}"


def _decode_cloudflare_emails(soup: BeautifulSoup) -> None:
    """data-cfemail 난독화를 평문 이메일로 되돌린다(첫 바이트가 XOR 키)."""
    for node in soup.select(CF_EMAIL_SELECTOR):
        encoded = bytes.fromhex(str(node["data-cfemail"]))
        key = encoded[0]
        email = "".join(chr(byte ^ key) for byte in encoded[1:])
        node.replace_with(email)
