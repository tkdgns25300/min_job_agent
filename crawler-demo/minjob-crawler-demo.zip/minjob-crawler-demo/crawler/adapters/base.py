"""소스 어댑터 인터페이스."""

from __future__ import annotations

from abc import ABC, abstractmethod

from crawler.models import PostingRef, RawPosting


class SourceAdapter(ABC):
    """게시판 소스 1개당 어댑터 1개. 목록 조회와 상세 raw 추출만 책임진다."""

    source_key: str
    board_name: str
    default_denomination: str
    crawl_mode: str  # "A"(공개 게시판 직접 크롤) | "B"

    @abstractmethod
    def list_postings(self, limit: int) -> list[PostingRef]:
        """목록 페이지에서 최근 글 참조를 최대 limit건 반환."""

    @abstractmethod
    def fetch_posting(self, ref: PostingRef) -> RawPosting:
        """상세 페이지를 읽어 raw 공고 1건을 완성."""
