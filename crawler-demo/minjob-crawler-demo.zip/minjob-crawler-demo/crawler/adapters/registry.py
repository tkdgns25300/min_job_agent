"""source_key → 어댑터 팩토리 레지스트리."""

from __future__ import annotations

from crawler.adapters.base import SourceAdapter
from crawler.adapters.kehc import KehcAdapter
from crawler.adapters.koreabaptist import KoreaBaptistAdapter
from crawler.adapters.prok import ProkAdapter
from crawler.adapters.ytus import YtusAdapter

_ADAPTER_CLASSES: dict[str, type[SourceAdapter]] = {
    YtusAdapter.source_key: YtusAdapter,
    KehcAdapter.source_key: KehcAdapter,
    KoreaBaptistAdapter.source_key: KoreaBaptistAdapter,
    ProkAdapter.source_key: ProkAdapter,
}


def list_source_keys() -> list[str]:
    return sorted(_ADAPTER_CLASSES)


def list_sources_meta() -> list[dict[str, str]]:
    """어드민 UI용 소스 메타(키·게시판명·기본 교단·크롤 모드)."""
    return [
        {
            "source_key": adapter_class.source_key,
            "board_name": adapter_class.board_name,
            "default_denomination": adapter_class.default_denomination,
            "crawl_mode": adapter_class.crawl_mode,
        }
        for adapter_class in sorted(_ADAPTER_CLASSES.values(), key=lambda c: c.source_key)
    ]


def create_adapter(source_key: str, offline: bool = False) -> SourceAdapter:
    adapter_class = _ADAPTER_CLASSES.get(source_key)
    if adapter_class is None:
        raise KeyError(f"unknown source_key: {source_key} (available: {list_source_keys()})")
    return adapter_class(offline=offline)
