"""한국기독교장로회(기장) 총회 '교역자 청빙' 게시판 어댑터 (dimode 솔루션).

주의(2026-07 확인): 목록은 공개지만 상세는 회원 로그인 전용이라
fetch_posting은 목록 메타만 채우고 extra.detail_access="login_required"로 표시된다.
"""

from __future__ import annotations

from crawler.adapters.dimode_board import DimodeBoardAdapter


class ProkAdapter(DimodeBoardAdapter):
    source_key = "prok"
    board_name = "한국기독교장로회 교역자 청빙"
    default_denomination = "ETC"
    crawl_mode = "A"

    base_url = "https://www.prok.org"
    board_id = "176244"
