"""기독교한국침례회 총회 '목회자청빙' 게시판 어댑터 (dimode 솔루션)."""

from __future__ import annotations

from crawler.adapters.dimode_board import DimodeBoardAdapter


class KoreaBaptistAdapter(DimodeBoardAdapter):
    source_key = "koreabaptist"
    board_name = "기독교한국침례회 목회자청빙"
    default_denomination = "BAPTIST"
    crawl_mode = "A"

    base_url = "https://www.koreabaptist.or.kr"
    board_id = "21317"
