"""어댑터 공용 헬퍼: 샘플 폴백 로딩 + HTML 텍스트 추출 + 정수 파싱.

모든 어댑터(ytus·dimode 계열·kehc)가 공유한다.
"""

from __future__ import annotations

import logging
from pathlib import Path

from bs4.element import Tag

from crawler.fetch.http import FetchError, fetch_html

logger = logging.getLogger(__name__)

SAMPLES_DIR = Path(__file__).resolve().parent.parent / "samples"

# 줄바꿈 경계로 취급할 블록 요소 — 인라인(span 등)은 브라우저처럼 이어 붙인다
_BLOCK_TAGS = ["p", "div", "li", "tr", "h1", "h2", "h3", "h4", "blockquote"]


def load_html(url: str, sample_file: Path, offline: bool) -> str:
    """라이브 fetch를 시도하고, offline 모드거나 실패하면 samples/ HTML로 폴백."""
    if offline:
        logger.info("offline 모드: 샘플 사용 %s", sample_file.name)
        return sample_file.read_text(encoding="utf-8")
    try:
        return fetch_html(url)
    except FetchError:
        logger.warning("라이브 fetch 실패 → 샘플 폴백: %s", sample_file.name)
        return sample_file.read_text(encoding="utf-8")


def extract_body_text(body: Tag) -> str:
    """본문을 렌더링 결과에 가깝게 텍스트로 추출한다(내용 손실 없음)."""
    for br in body.find_all("br"):
        br.replace_with("\n")
    for block in body.find_all(_BLOCK_TAGS):
        block.append("\n")
    lines = [line.strip() for line in body.get_text().replace("\xa0", " ").splitlines()]
    return "\n".join(line for line in lines if line)


def parse_int(text: str | None) -> int | None:
    if text is None:
        return None
    digits = text.replace(",", "")
    return int(digits) if digits.isdigit() else None
