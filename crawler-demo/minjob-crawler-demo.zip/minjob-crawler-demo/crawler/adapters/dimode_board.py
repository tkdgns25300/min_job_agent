"""dimode(디모데정보통신) .NET 게시판 솔루션 공용 베이스.

koreabaptist(침례회)와 prok(기장) 총회 홈페이지가 같은 솔루션을 쓴다
(2026-07 두 사이트 HTML 대조로 확인 — #dimodeBoard / td.document-* / /Board/Detail/{board}/{doc}).

페이지 구조:
- 목록: div#dimodeBoard.board-list table tbody tr
  > td.document-number(공지 행은 숫자 대신 "공지", tr.notice 클래스도 붙음)
  > td.document-title a[href=/Board/Detail/..] / td.document-writer
  > td.document-regdate(YYYY-MM-DD) / td.document-readedcount
- 상세: div#dimodeBoard.board-detail div.theme-detail
  > .detail-top .document-title / .detail-top .document-regdate(YYYY-MM-DD HH:MM:SS)
  > .detail-upper .document-writer / .document-readed_count b
  > .detail-content(본문 — 공고가 이미지 1장인 글이 많아 img도 첨부로 수집)
  > 첨부: .detail-content a[href*=/File/Download]
- 상세가 로그인 전용인 보드는 "로그인 후 이용해주시기 바랍니다" 안내만 렌더링됨.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from bs4.element import Tag

from crawler.adapters.base import SourceAdapter
from crawler.adapters.common import SAMPLES_DIR, extract_body_text, load_html, parse_int
from crawler.models import PostingRef, RawPosting

logger = logging.getLogger(__name__)

LIST_ROW_SELECTOR = "div#dimodeBoard.board-list table tbody tr"
LIST_TITLE_LINK_SELECTOR = "td.document-title a[href]"
LIST_NUMBER_SELECTOR = "td.document-number"
LIST_WRITER_SELECTOR = "td.document-writer"
LIST_REGDATE_SELECTOR = "td.document-regdate"
LIST_READCOUNT_SELECTOR = "td.document-readedcount"
NOTICE_ROW_CLASS = "notice"

DETAIL_CONTAINER_SELECTOR = "div#dimodeBoard.board-detail div.theme-detail"
DETAIL_TITLE_SELECTOR = "div.detail-top div.document-title"
DETAIL_REGDATE_SELECTOR = "div.detail-top div.document-regdate"
DETAIL_WRITER_SELECTOR = "div.detail-upper div.document-writer"
DETAIL_READCOUNT_SELECTOR = "div.document-readed_count b"
DETAIL_BODY_SELECTOR = "div.detail-content"
DETAIL_FILE_LINK_SELECTOR = "a[href*='/File/Download']"

LOGIN_WALL_MARKER = "로그인 후 이용해주시기 바랍니다"

_HTML_PARSER = "lxml"


class DimodeBoardAdapter(SourceAdapter):
    """dimode 게시판 소스 공용 구현. 서브클래스는 사이트/보드 식별자만 정의한다."""

    base_url: str
    board_id: str

    def __init__(self, offline: bool = False) -> None:
        self._offline = offline
        self._sample_list_file = SAMPLES_DIR / f"{self.source_key}_list.html"
        self._sample_detail_file = SAMPLES_DIR / f"{self.source_key}_detail.html"

    @property
    def list_url(self) -> str:
        return f"{self.base_url}/Board/Index/{self.board_id}"

    def list_postings(self, limit: int) -> list[PostingRef]:
        html = load_html(self.list_url, self._sample_list_file, self._offline)
        soup = BeautifulSoup(html, _HTML_PARSER)
        refs = [
            ref
            for row in soup.select(LIST_ROW_SELECTOR)
            if (ref := self._parse_list_row(row)) is not None
        ]
        return refs[:limit]

    def fetch_posting(self, ref: PostingRef) -> RawPosting:
        html = load_html(ref.post_url, self._sample_detail_file, self._offline)
        if LOGIN_WALL_MARKER in html:
            # 상세가 회원 전용인 보드(예: prok) — 목록 메타만으로 raw를 남기고 표시한다
            logger.warning("%s: 상세가 로그인 전용 → 목록 메타만 수집 (%s)", self.source_key, ref.post_url)
            return self._build_posting(ref, raw_text="", attachments=[], links=[],
                                       extra_note={"detail_access": "login_required"})
        return self._parse_detail(html, ref)

    # --- 목록 파싱 ---

    def _parse_list_row(self, row: Tag) -> PostingRef | None:
        link = row.select_one(LIST_TITLE_LINK_SELECTOR)
        number_cell = row.select_one(LIST_NUMBER_SELECTOR)
        if link is None or number_cell is None:
            return None
        list_num = number_cell.get_text(strip=True)
        row_classes = row.get("class") or []
        if NOTICE_ROW_CLASS in row_classes or not list_num.isdigit():
            return None  # 공지(고정) 행 — 청빙 공고가 아님

        post_url = urljoin(self.base_url, str(link["href"]))
        return PostingRef(
            external_id=post_url.rstrip("/").rsplit("/", 1)[-1],
            title=link.get_text(strip=True),
            post_url=post_url,
            author=_cell_text(row, LIST_WRITER_SELECTOR),
            posted_at=_cell_text(row, LIST_REGDATE_SELECTOR),
            view_count=parse_int(_cell_text(row, LIST_READCOUNT_SELECTOR)),
            extra={"list_num": list_num},
        )

    # --- 상세 파싱 ---

    def _parse_detail(self, html: str, ref: PostingRef) -> RawPosting:
        soup = BeautifulSoup(html, _HTML_PARSER)
        container = soup.select_one(DETAIL_CONTAINER_SELECTOR)
        if container is None:
            raise ValueError(f"detail container not found: {ref.post_url}")

        body = container.select_one(DETAIL_BODY_SELECTOR)
        title_node = container.select_one(DETAIL_TITLE_SELECTOR)
        regdate = _node_text(container, DETAIL_REGDATE_SELECTOR)
        writer = _node_text(container, DETAIL_WRITER_SELECTOR)
        read_count = parse_int(_node_text(container, DETAIL_READCOUNT_SELECTOR))

        return self._build_posting(
            ref,
            raw_text=extract_body_text(body) if body else "",
            attachments=self._parse_attachments(body),
            links=self._parse_body_links(body),
            title=title_node.get_text(strip=True) if title_node else None,
            author=writer,
            posted_at=regdate.split()[0] if regdate else None,  # "YYYY-MM-DD HH:MM:SS" → 날짜만
            view_count=read_count,
        )

    def _parse_attachments(self, body: Tag | None) -> list[dict[str, str]]:
        if body is None:
            return []
        files = [
            {"name": link.get_text(strip=True), "url": urljoin(self.base_url, str(link["href"]))}
            for link in body.select(DETAIL_FILE_LINK_SELECTOR)
        ]
        # 공고 전문을 이미지 1장으로 올리는 글이 많아, 본문 이미지도 첨부로 보존한다
        images = [
            {"name": str(img.get("alt") or img.get("title") or ""), "url": urljoin(self.base_url, str(img["src"]))}
            for img in body.select("img[src]")
        ]
        return files + images

    def _parse_body_links(self, body: Tag | None) -> list[str]:
        if body is None:
            return []
        return [urljoin(self.base_url, str(link["href"])) for link in body.select("a[href]")]

    def _build_posting(
        self,
        ref: PostingRef,
        raw_text: str,
        attachments: list[dict[str, str]],
        links: list[str],
        title: str | None = None,
        author: str | None = None,
        posted_at: str | None = None,
        view_count: int | None = None,
        extra_note: dict[str, str] | None = None,
    ) -> RawPosting:
        return RawPosting(
            source_key=self.source_key,
            board_name=self.board_name,
            list_url=self.list_url,
            post_url=ref.post_url,
            external_id=ref.external_id,
            title=title or ref.title,
            author=author or ref.author,
            posted_at=posted_at or ref.posted_at,
            view_count=view_count if view_count is not None else ref.view_count,
            raw_text=raw_text,
            attachments=attachments,
            links=links,
            extra={**ref.extra, **(extra_note or {})},
            default_denomination=self.default_denomination,
            crawl_mode=self.crawl_mode,
            fetched_at=datetime.now(timezone.utc).isoformat(),
        )


def _cell_text(row: Tag, selector: str) -> str | None:
    cell = row.select_one(selector)
    text = cell.get_text(strip=True) if cell else ""
    return text or None


def _node_text(container: Tag, selector: str) -> str | None:
    node = container.select_one(selector)
    text = node.get_text(strip=True) if node else ""
    return text or None
