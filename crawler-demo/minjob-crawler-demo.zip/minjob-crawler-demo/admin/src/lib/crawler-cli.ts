import { execFile } from "node:child_process";
import path from "node:path";
import type { RawPosting, SourceInfo } from "@/lib/types";

/** 크롤러 데모 루트(= admin/의 부모). python -m crawler는 반드시 이 cwd에서 실행한다. */
export const CRAWLER_ROOT = process.env.CRAWLER_ROOT ?? path.resolve(process.cwd(), "..");

const PYTHON_BIN = process.env.PYTHON_BIN ?? "python3";
const CRAWL_TIMEOUT_MS = 120_000;
// raw_text 원문이 길 수 있어 stdout 버퍼를 넉넉히 잡는다.
const MAX_STDOUT_BYTES = 32 * 1024 * 1024;

export class CrawlerCliError extends Error {
  constructor(message: string, readonly stderr: string = "") {
    super(message);
    this.name = "CrawlerCliError";
  }
}

/** stdout만 데이터로 취급하고 stderr는 서버 로그로만 남긴다. */
function runCrawlerCli(args: readonly string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(
      PYTHON_BIN,
      ["-m", "crawler", ...args],
      { cwd: CRAWLER_ROOT, timeout: CRAWL_TIMEOUT_MS, maxBuffer: MAX_STDOUT_BYTES },
      (error, stdout, stderr) => {
        if (stderr) {
          console.error(`[crawler ${args.join(" ")}]\n${stderr.trimEnd()}`);
        }
        if (error) {
          reject(new CrawlerCliError(`크롤러 실행 실패 (${args.join(" ")}): ${error.message}`, stderr));
          return;
        }
        resolve(stdout);
      },
    );
  });
}

function parseCliJson<T>(stdout: string, context: string): T {
  try {
    return JSON.parse(stdout) as T;
  } catch {
    throw new CrawlerCliError(`크롤러 출력 JSON 파싱 실패 (${context})`);
  }
}

export async function listSources(): Promise<SourceInfo[]> {
  const stdout = await runCrawlerCli(["--list-sources", "--json"]);
  return parseCliJson<SourceInfo[]>(stdout, "--list-sources");
}

export async function crawlSource(sourceKey: string, limit: number): Promise<RawPosting[]> {
  const stdout = await runCrawlerCli([sourceKey, "--limit", String(limit)]);
  return parseCliJson<RawPosting[]>(stdout, sourceKey);
}
