import { promises as fs } from "node:fs";
import path from "node:path";
import { CRAWLER_ROOT } from "@/lib/crawler-cli";
import type { RawPosting, StagedPosting } from "@/lib/types";
import { postingKey } from "@/lib/types";

/** 리뷰 큐 파일: 데모 루트의 data/staging.json */
const STAGING_FILE = path.join(CRAWLER_ROOT, "data", "staging.json");

export async function readStagedPostings(): Promise<StagedPosting[]> {
  try {
    const rawJson = await fs.readFile(STAGING_FILE, "utf8");
    return JSON.parse(rawJson) as StagedPosting[];
  } catch (error) {
    // 파일이 아직 없으면 빈 큐로 취급
    if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
    throw error;
  }
}

export type SaveResult =
  | { status: "saved"; record: StagedPosting }
  | { status: "duplicate" };

/** dedup 키(source_key + external_id)가 이미 있으면 저장하지 않고 duplicate로 알린다. */
export async function saveStagedPosting(posting: RawPosting): Promise<SaveResult> {
  const staged = await readStagedPostings();
  const isDuplicate = staged.some((record) => postingKey(record) === postingKey(posting));
  if (isDuplicate) return { status: "duplicate" };

  const record: StagedPosting = {
    ...posting,
    review_status: "PENDING",
    saved_at: new Date().toISOString(),
  };
  await fs.mkdir(path.dirname(STAGING_FILE), { recursive: true });
  await fs.writeFile(STAGING_FILE, JSON.stringify([...staged, record], null, 2), "utf8");
  return { status: "saved", record };
}
