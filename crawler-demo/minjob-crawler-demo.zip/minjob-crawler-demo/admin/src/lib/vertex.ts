import { GoogleGenAI, Type, type Schema } from "@google/genai";
import type { RawPosting } from "@/lib/types";
import {
  CONFIDENCE_LEVELS,
  DENOMINATION_KEYS,
  DEPARTMENT_KEYS,
  EMPLOYMENT_TYPE_KEYS,
  POSITION_KEYS,
  type ConfidenceLevel,
  type DenominationKey,
  type DepartmentKey,
  type EmploymentTypeKey,
  type PositionKey,
  type StructuredPreview,
} from "@/lib/structured-preview";

// 구조화 AI = Vertex AI의 Gemini(Flash). 사용자 GCP 프로젝트에 활성화된 모델.
const DEFAULT_VERTEX_LOCATION = "global";
const DEFAULT_VERTEX_MODEL = "gemini-2.5-flash";
const MAX_OUTPUT_TOKENS = 1024;
// 본문이 비정상적으로 길어도 프롬프트가 폭주하지 않도록 상한을 둔다.
const MAX_RAW_TEXT_CHARS = 12_000;

// Vertex 429(RESOURCE_EXHAUSTED)·503(UNAVAILABLE)·5xx는 일시적 → 지수 백오프 + 지터로 재시도.
const MAX_RETRY_ATTEMPTS = 5;
const BASE_RETRY_DELAY_MS = 1_000;
const MAX_RETRY_DELAY_MS = 30_000;

const SYSTEM_PROMPT = `당신은 한국 교회 청빙(교역자 채용) 공고를 구조화하는 어시스턴트입니다.
교회 게시판에서 크롤링한 청빙 공고 원문을 읽고 지정된 JSON 스키마로 핵심 필드를 추출합니다.

도메인 지식:
- 청빙 공고는 교회가 담임목사·부목사·전도사·강도사 등 교역자를 모집하는 글입니다.
- 교단(합동, 통합, 백석, 감리, 순복음, 침례, 성결, 고신, 합신 등)과 사역 부서(영유아부, 유초등부, 중고등부, 청년부, 교구, 찬양/예배, 행정 등)가 자주 명시됩니다.
- "사례비"는 교역자에게 지급하는 보수를 뜻하며, 원문 표현("교회 내규에 따름", "협의" 등)을 그대로 보존해야 합니다.
- 고용 형태는 전임(FULL_TIME), 준전임(SEMI_FULL_TIME), 파트(PART_TIME)로 구분합니다.

규칙:
- 반드시 주어진 enum key로만 매핑하고, 확실하지 않으면 ETC 또는 null을 사용합니다.
- 원문에 없는 정보를 지어내지 않습니다.
- 개인 담당자의 연락처(전화번호, 이메일, 카카오톡 ID 등)는 어떤 필드에도 추출하지 않습니다.`;

/** Gemini 구조화 출력 스키마 — StructuredPreview 필드를 강제한다(config.responseSchema). */
const RESPONSE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    church_name: { type: Type.STRING, nullable: true, description: "교회 이름. 원문에 없으면 null." },
    denomination: {
      type: Type.STRING,
      enum: [...DENOMINATION_KEYS],
      description: "교단 key. 명시가 없으면 힌트(default_denomination)를 참고하고, 그래도 불명확하면 ETC.",
    },
    region: { type: Type.STRING, nullable: true, description: "교회 소재 지역(예: '서울 강남구'). 없으면 null." },
    position: {
      type: Type.STRING,
      enum: [...POSITION_KEYS],
      description: "모집 직분 key. 매핑 불가하면 ETC.",
    },
    department: {
      type: Type.STRING,
      enum: [...DEPARTMENT_KEYS],
      nullable: true,
      description: "담당 부서 key. 명시가 없으면 null.",
    },
    employment_type: {
      type: Type.STRING,
      enum: [...EMPLOYMENT_TYPE_KEYS],
      nullable: true,
      description: "고용 형태 key. 명시가 없으면 null.",
    },
    stipend_note: {
      type: Type.STRING,
      nullable: true,
      description: "사례비 관련 원문 표현을 그대로 보존(예: '교회 내규에 따름'). 없으면 null.",
    },
    deadline: {
      type: Type.STRING,
      nullable: true,
      description: "지원 마감일. 가능하면 YYYY-MM-DD, 아니면 원문 표현. 없으면 null.",
    },
    summary: { type: Type.STRING, description: "공고 핵심을 담은 한국어 1~2문장 요약. 개인 연락처 포함 금지." },
    confidence: {
      type: Type.STRING,
      enum: [...CONFIDENCE_LEVELS],
      description: "추출 전반의 확신도.",
    },
  },
  required: [
    "church_name",
    "denomination",
    "region",
    "position",
    "department",
    "employment_type",
    "stipend_note",
    "deadline",
    "summary",
    "confidence",
  ],
};

export class VertexConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "VertexConfigError";
  }
}

function requireEnv(name: string): string {
  const value = process.env[name];
  if (value === undefined || value === "") {
    throw new VertexConfigError(`환경변수 ${name}이(가) 설정되지 않았습니다 (admin/.env 확인)`);
  }
  return value;
}

let cachedClient: GoogleGenAI | null = null;

/** 빌드 시점이 아닌 첫 요청 시점에 환경변수를 검증하도록 lazy 생성한다. */
function getClient(): GoogleGenAI {
  if (cachedClient !== null) return cachedClient;

  cachedClient = new GoogleGenAI({
    vertexai: true,
    project: requireEnv("VERTEX_AI_PROJECT_ID"),
    location: process.env.VERTEX_AI_LOCATION ?? DEFAULT_VERTEX_LOCATION,
    googleAuthOptions: {
      credentials: {
        client_email: requireEnv("VERTEX_AI_CLIENT_EMAIL"),
        private_key: requireEnv("VERTEX_AI_PRIVATE_KEY").replace(/\\n/g, "\n"),
      },
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    },
  });
  return cachedClient;
}

function isOneOf<T extends string>(candidates: readonly T[], value: unknown): value is T {
  return typeof value === "string" && (candidates as readonly string[]).includes(value);
}

function asNullableString(value: unknown): string | null {
  return typeof value === "string" && value.trim() !== "" ? value : null;
}

/** 모델이 enum을 벗어난 값을 내도 UI가 깨지지 않도록 방어적으로 정규화한다. */
function normalizePreview(input: Record<string, unknown>): StructuredPreview {
  const denomination: DenominationKey = isOneOf(DENOMINATION_KEYS, input.denomination)
    ? input.denomination
    : "ETC";
  const position: PositionKey = isOneOf(POSITION_KEYS, input.position) ? input.position : "ETC";
  const department: DepartmentKey | null = isOneOf(DEPARTMENT_KEYS, input.department)
    ? input.department
    : null;
  const employmentType: EmploymentTypeKey | null = isOneOf(EMPLOYMENT_TYPE_KEYS, input.employment_type)
    ? input.employment_type
    : null;
  const confidence: ConfidenceLevel = isOneOf(CONFIDENCE_LEVELS, input.confidence)
    ? input.confidence
    : "low";

  return {
    church_name: asNullableString(input.church_name),
    denomination,
    region: asNullableString(input.region),
    position,
    department,
    employment_type: employmentType,
    stipend_note: asNullableString(input.stipend_note),
    deadline: asNullableString(input.deadline),
    summary: typeof input.summary === "string" ? input.summary : "",
    confidence,
  };
}

function buildUserPrompt(raw: RawPosting): string {
  const rawText =
    raw.raw_text.length > MAX_RAW_TEXT_CHARS
      ? `${raw.raw_text.slice(0, MAX_RAW_TEXT_CHARS)}\n…(이하 생략)`
      : raw.raw_text;

  return [
    "다음 청빙 공고를 구조화해 주세요.",
    "",
    `제목: ${raw.title}`,
    `게시판: ${raw.board_name}`,
    `게시일: ${raw.posted_at ?? "미상"}`,
    `교단 힌트(default_denomination): ${raw.default_denomination}`,
    "",
    "본문:",
    rawText,
  ].join("\n");
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 429(RESOURCE_EXHAUSTED)·503(UNAVAILABLE)·5xx만 재시도 대상 — 그 외(400·인증 등)는 즉시 실패. */
function isRetryableError(error: unknown): boolean {
  const candidate = error as { status?: unknown; code?: unknown; message?: unknown };
  const status =
    typeof candidate?.status === "number"
      ? candidate.status
      : typeof candidate?.code === "number"
        ? candidate.code
        : undefined;
  if (status !== undefined) {
    return status === 429 || (status >= 500 && status < 600);
  }
  const message = typeof candidate?.message === "string" ? candidate.message : String(error);
  return /RESOURCE_EXHAUSTED|UNAVAILABLE|\b429\b|\b50[0-9]\b/i.test(message);
}

/** attempt(1부터)에 대한 백오프 지연: base*2^(n-1)를 상한으로 자르고 50~100% 지터를 준다. */
function backoffDelayMs(attempt: number): number {
  const capped = Math.min(MAX_RETRY_DELAY_MS, BASE_RETRY_DELAY_MS * 2 ** (attempt - 1));
  return Math.round(capped * (0.5 + Math.random() * 0.5));
}

function describeError(error: unknown): string {
  const candidate = error as { status?: unknown; message?: unknown };
  const prefix = typeof candidate?.status === "number" ? `HTTP ${candidate.status} ` : "";
  const message = typeof candidate?.message === "string" ? candidate.message : String(error);
  return `${prefix}${message}`.slice(0, 200);
}

/** 일시적 오류에 한해 지수 백오프로 재시도. 재시도 불가 오류나 시도 소진 시 원 오류를 그대로 던진다. */
async function withRetry<T>(operation: () => Promise<T>, label: string): Promise<T> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= MAX_RETRY_ATTEMPTS; attempt += 1) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      if (!isRetryableError(error) || attempt === MAX_RETRY_ATTEMPTS) throw error;
      const delayMs = backoffDelayMs(attempt);
      console.error(
        `[vertex] ${label} 일시적 오류 — 재시도 ${attempt}/${MAX_RETRY_ATTEMPTS - 1}, ${delayMs}ms 후 (원인: ${describeError(error)})`,
      );
      await sleep(delayMs);
    }
  }
  throw lastError;
}

/** raw 공고 1건을 Gemini(responseSchema)로 구조화한다 — 미리보기 전용, 어디에도 저장하지 않는다. */
export async function structurePosting(raw: RawPosting): Promise<StructuredPreview> {
  const client = getClient();

  // 429/일시적 오류는 지수 백오프로 재시도(rate limit 대응). 파싱·검증은 재시도 대상 아님.
  const response = await withRetry(
    () =>
      client.models.generateContent({
        model: process.env.VERTEX_MODEL ?? DEFAULT_VERTEX_MODEL,
        contents: buildUserPrompt(raw),
        config: {
          systemInstruction: SYSTEM_PROMPT,
          responseMimeType: "application/json",
          responseSchema: RESPONSE_SCHEMA,
          maxOutputTokens: MAX_OUTPUT_TOKENS,
          temperature: 0,
          // 추출 작업이라 사고(thinking) 비활성 — 지연·토큰 절약 + JSON 출력 보장 (2.5 flash)
          thinkingConfig: { thinkingBudget: 0 },
        },
      }),
    "generateContent",
  );

  const text = response.text;
  if (text === undefined || text === "") {
    throw new Error("모델 응답이 비었습니다");
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error("모델 출력 JSON 파싱 실패");
  }
  return normalizePreview(parsed as Record<string, unknown>);
}
