/** Python 크롤러의 RawPosting을 그대로 미러한 타입 — 필드 임의 변경 금지. */

export interface Attachment {
  name: string;
  url: string;
}

export interface RawPosting {
  source_key: string;
  board_name: string;
  list_url: string;
  post_url: string;
  external_id: string;
  title: string;
  author: string | null;
  posted_at: string | null; // "YYYY-MM-DD"
  view_count: number | null;
  raw_text: string;
  attachments: Attachment[];
  links: string[];
  extra: Record<string, string>;
  default_denomination: string;
  crawl_mode: string; // "A" | "B"
  fetched_at: string; // ISO8601
}

export interface SourceInfo {
  source_key: string;
  board_name: string;
  default_denomination: string;
  crawl_mode: string;
}

export type ReviewStatus = "PENDING";

/** 리뷰 큐(staging.json)에 저장되는 레코드. */
export interface StagedPosting extends RawPosting {
  review_status: ReviewStatus;
  saved_at: string; // ISO8601
}

/** dedup 키 = source_key + external_id */
export function postingKey(posting: Pick<RawPosting, "source_key" | "external_id">): string {
  return `${posting.source_key}:${posting.external_id}`;
}
