/** 교단 key → 한글 라벨. 크롤러의 default_denomination 값과 1:1. */
export const DENOMINATION_LABELS: Record<string, string> = {
  HAPDONG: "예장합동",
  TONGHAP: "예장통합",
  BAEKSEOK: "예장백석",
  GAMLI: "감리교",
  SUNBOK: "순복음",
  BAPTIST: "침례교",
  SEONGGYUL: "성결교",
  GOSIN: "예장고신",
  HAPSIN: "예장합신",
  ETC: "기타",
};

export function denominationLabel(key: string): string {
  return DENOMINATION_LABELS[key] ?? key;
}
