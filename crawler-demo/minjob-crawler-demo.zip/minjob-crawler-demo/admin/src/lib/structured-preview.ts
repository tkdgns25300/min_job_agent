/**
 * 구조화 미리보기(StructuredPreview) 타입·enum·한글 라벨.
 * 서버(vertex.ts)와 클라이언트(카드 UI)가 함께 쓰므로 SDK 의존성 없이 분리한다.
 * enum key는 min_job 스키마의 부분집합 — 임의 변경 금지.
 */

export const DENOMINATION_KEYS = [
  "HAPDONG",
  "TONGHAP",
  "BAEKSEOK",
  "GAMLI",
  "SUNBOK",
  "BAPTIST",
  "SEONGGYUL",
  "GOSIN",
  "HAPSIN",
  "ETC",
] as const;
export type DenominationKey = (typeof DENOMINATION_KEYS)[number];

export const POSITION_KEYS = [
  "SENIOR_PASTOR",
  "ASSOCIATE_PASTOR",
  "EVANGELIST",
  "LICENSED_MINISTER",
  "ETC",
] as const;
export type PositionKey = (typeof POSITION_KEYS)[number];

export const DEPARTMENT_KEYS = [
  "INFANT",
  "CHILDREN",
  "YOUTH",
  "YOUNG_ADULT",
  "DISTRICT",
  "WORSHIP",
  "ADMIN",
  "ETC",
] as const;
export type DepartmentKey = (typeof DEPARTMENT_KEYS)[number];

export const EMPLOYMENT_TYPE_KEYS = ["FULL_TIME", "SEMI_FULL_TIME", "PART_TIME"] as const;
export type EmploymentTypeKey = (typeof EMPLOYMENT_TYPE_KEYS)[number];

export const CONFIDENCE_LEVELS = ["high", "medium", "low"] as const;
export type ConfidenceLevel = (typeof CONFIDENCE_LEVELS)[number];

/** Vertex(Claude) 구조화 결과 — 저장·DB와 무관한 미리보기 전용. */
export interface StructuredPreview {
  church_name: string | null;
  denomination: DenominationKey;
  region: string | null;
  position: PositionKey;
  department: DepartmentKey | null;
  employment_type: EmploymentTypeKey | null;
  stipend_note: string | null;
  deadline: string | null;
  summary: string;
  confidence: ConfidenceLevel;
}

export const POSITION_LABELS: Record<PositionKey, string> = {
  SENIOR_PASTOR: "담임목사",
  ASSOCIATE_PASTOR: "부목사",
  EVANGELIST: "전도사",
  LICENSED_MINISTER: "강도사",
  ETC: "기타",
};

export const DEPARTMENT_LABELS: Record<DepartmentKey, string> = {
  INFANT: "영유아부",
  CHILDREN: "유초등부",
  YOUTH: "중고등부",
  YOUNG_ADULT: "청년부",
  DISTRICT: "교구",
  WORSHIP: "찬양/예배",
  ADMIN: "행정",
  ETC: "기타",
};

export const EMPLOYMENT_TYPE_LABELS: Record<EmploymentTypeKey, string> = {
  FULL_TIME: "전임",
  SEMI_FULL_TIME: "준전임",
  PART_TIME: "파트",
};

export const CONFIDENCE_LABELS: Record<ConfidenceLevel, string> = {
  high: "높음",
  medium: "중간",
  low: "낮음",
};
