import { listSources } from "@/lib/crawler-cli";
import { CrawlConsole } from "@/components/crawl-console";

// 소스 목록은 요청 시점에 크롤러 CLI로 조회한다 (빌드 시 고정 방지)
export const dynamic = "force-dynamic";

export default async function HomePage() {
  const sources = await listSources();
  return <CrawlConsole sources={sources} />;
}
