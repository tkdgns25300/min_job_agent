import { readStagedPostings } from "@/lib/staging-store";
import { DenominationTag } from "@/components/badges";

// staging.json은 요청마다 다시 읽는다
export const dynamic = "force-dynamic";

function formatSavedAt(savedAtIso: string): string {
  const parsed = new Date(savedAtIso);
  return Number.isNaN(parsed.getTime()) ? savedAtIso : parsed.toLocaleString("ko-KR");
}

export default async function SavedPage() {
  const records = await readStagedPostings();

  return (
    <div>
      <div className="flex items-baseline gap-3">
        <h1 className="text-lg font-bold">저장된 데이터 (리뷰 큐)</h1>
        <span className="text-sm text-gray-500">{records.length}건</span>
      </div>

      {records.length === 0 ? (
        <p className="mt-4 rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-400">
          아직 저장된 공고가 없습니다. 크롤 실행 후 카드에서 저장하세요.
        </p>
      ) : (
        <ul className="mt-4 space-y-3">
          {records.map((record) => (
            <li
              key={`${record.source_key}:${record.external_id}`}
              className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm"
            >
              <div className="flex flex-wrap items-center gap-2">
                <DenominationTag denomination={record.default_denomination} />
                <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                  {record.review_status}
                </span>
              </div>
              <h2 className="mt-2 text-sm font-semibold leading-snug">{record.title}</h2>
              <p className="mt-1 text-xs text-gray-500">
                {record.board_name} · 저장 {formatSavedAt(record.saved_at)}
              </p>
              <a
                href={record.post_url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-block text-xs font-medium text-blue-600 hover:underline"
              >
                원문 보기 ↗
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
