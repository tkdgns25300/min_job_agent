import { NextResponse } from "next/server";
import type { RawPosting } from "@/lib/types";
import { structurePosting } from "@/lib/vertex";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let posting: RawPosting;
  try {
    posting = (await request.json()) as RawPosting;
  } catch {
    return NextResponse.json({ error: "잘못된 JSON body" }, { status: 400 });
  }

  if (typeof posting.raw_text !== "string" || posting.raw_text.trim() === "") {
    return NextResponse.json({ error: "구조화할 본문이 없습니다" }, { status: 400 });
  }

  try {
    const preview = await structurePosting(posting);
    return NextResponse.json(preview);
  } catch (error) {
    // Vertex 인증/모델 오류를 진단할 수 있도록 원문 메시지를 그대로 내려준다.
    const message = error instanceof Error ? error.message : "구조화 실패";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
