import { NextResponse } from "next/server";
import { readStagedPostings } from "@/lib/staging-store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const records = await readStagedPostings();
    return NextResponse.json({ count: records.length, records });
  } catch {
    return NextResponse.json({ error: "저장 데이터 조회 실패" }, { status: 500 });
  }
}
