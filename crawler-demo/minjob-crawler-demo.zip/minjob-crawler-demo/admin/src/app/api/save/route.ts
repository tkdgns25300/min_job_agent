import { NextResponse } from "next/server";
import { saveStagedPosting } from "@/lib/staging-store";
import type { RawPosting } from "@/lib/types";

export const dynamic = "force-dynamic";

/** dedup·표시에 필요한 최소 필드만 검증한다(나머지는 크롤러 산출물 그대로 통과). */
function isRawPosting(value: unknown): value is RawPosting {
  if (typeof value !== "object" || value === null) return false;
  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate.source_key === "string" &&
    typeof candidate.external_id === "string" &&
    typeof candidate.title === "string" &&
    typeof candidate.post_url === "string"
  );
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "잘못된 JSON body" }, { status: 400 });
  }
  if (!isRawPosting(body)) {
    return NextResponse.json(
      { error: "RawPosting 형식이 아닙니다 (source_key/external_id/title/post_url 필요)" },
      { status: 400 },
    );
  }

  try {
    const result = await saveStagedPosting(body);
    return NextResponse.json(result, { status: result.status === "saved" ? 201 : 200 });
  } catch {
    return NextResponse.json({ error: "저장 실패" }, { status: 500 });
  }
}
