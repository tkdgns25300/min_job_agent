import { NextResponse } from "next/server";
import { CrawlerCliError, crawlSource, listSources } from "@/lib/crawler-cli";

export const dynamic = "force-dynamic";

const MIN_LIMIT = 1;
const MAX_LIMIT = 30;

interface CrawlRequestBody {
  source?: unknown;
  limit?: unknown;
}

export async function POST(request: Request) {
  let body: CrawlRequestBody;
  try {
    body = (await request.json()) as CrawlRequestBody;
  } catch {
    return NextResponse.json({ error: "잘못된 JSON body" }, { status: 400 });
  }

  const source = body.source;
  const limit = body.limit;
  if (typeof source !== "string" || source.length === 0) {
    return NextResponse.json({ error: "source(문자열)가 필요합니다" }, { status: 400 });
  }
  if (typeof limit !== "number" || !Number.isInteger(limit) || limit < MIN_LIMIT || limit > MAX_LIMIT) {
    return NextResponse.json(
      { error: `limit은 ${MIN_LIMIT}~${MAX_LIMIT} 사이의 정수여야 합니다` },
      { status: 400 },
    );
  }

  try {
    // 존재하지 않는 소스를 CLI에 넘기기 전에 등록 목록으로 검증한다.
    const sources = await listSources();
    if (!sources.some((s) => s.source_key === source)) {
      return NextResponse.json({ error: `존재하지 않는 소스: ${source}` }, { status: 404 });
    }
    const postings = await crawlSource(source, limit);
    return NextResponse.json(postings);
  } catch (error) {
    const message = error instanceof CrawlerCliError ? error.message : "크롤 실행 실패";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
