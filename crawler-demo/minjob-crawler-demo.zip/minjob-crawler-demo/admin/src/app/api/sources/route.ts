import { NextResponse } from "next/server";
import { CrawlerCliError, listSources } from "@/lib/crawler-cli";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const sources = await listSources();
    return NextResponse.json(sources);
  } catch (error) {
    const message = error instanceof CrawlerCliError ? error.message : "소스 목록 조회 실패";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
