import { denominationLabel } from "@/lib/denominations";

/** 교단 태그 (한글 라벨) */
export function DenominationTag({ denomination }: { denomination: string }) {
  return (
    <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-0.5 text-xs font-medium text-blue-700">
      {denominationLabel(denomination)}
    </span>
  );
}

/** 크롤 모드 배지 ("A" | "B") */
export function ModeBadge({ mode }: { mode: string }) {
  return (
    <span className="inline-flex items-center rounded border border-gray-300 px-1.5 py-0.5 text-[10px] font-semibold text-gray-500">
      mode {mode}
    </span>
  );
}

/** 상세 페이지가 로그인 벽인 소스(prok 등)의 안내 배지 */
export function LoginRequiredBadge() {
  return (
    <span className="inline-flex items-center rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700">
      상세 로그인 필요
    </span>
  );
}
