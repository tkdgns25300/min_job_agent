"use client";

import { useState } from "react";
import type { RawPosting } from "@/lib/types";
import {
  CONFIDENCE_LABELS,
  DEPARTMENT_LABELS,
  EMPLOYMENT_TYPE_LABELS,
  POSITION_LABELS,
  type StructuredPreview,
} from "@/lib/structured-preview";
import { denominationLabel } from "@/lib/denominations";
import { DenominationTag, LoginRequiredBadge } from "@/components/badges";

const PREVIEW_MAX_CHARS = 160;
const DETAIL_ACCESS_LOGIN_REQUIRED = "login_required";
const EMPTY_FIELD_PLACEHOLDER = "—";

export type SaveState = "idle" | "saving" | "saved" | "duplicate";

const SAVE_BUTTON_LABELS: Record<SaveState, string> = {
  idle: "저장",
  saving: "저장 중…",
  saved: "저장됨",
  duplicate: "이미 저장됨",
};

type StructureState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "done"; preview: StructuredPreview };

interface ApiErrorBody {
  error?: string;
}

interface RawPostingCardProps {
  posting: RawPosting;
  saveState: SaveState;
  onSave: (posting: RawPosting) => void;
}

/** 구조화 결과를 "라벨: 값" 행으로 그린다. */
function PreviewField({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="flex gap-2">
      <dt className="w-16 shrink-0 font-medium text-gray-500">{label}</dt>
      <dd className={value === null ? "text-gray-400" : "text-gray-800"}>
        {value ?? EMPTY_FIELD_PLACEHOLDER}
      </dd>
    </div>
  );
}

function StructuredPreviewPanel({ preview }: { preview: StructuredPreview }) {
  return (
    <div className="mt-3 rounded-md border border-violet-200 bg-violet-50 p-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-violet-800">구조화 미리보기</span>
        <span className="text-[10px] text-violet-500">
          미리보기 전용 · 저장되지 않습니다 (확신도: {CONFIDENCE_LABELS[preview.confidence]})
        </span>
      </div>
      <dl className="mt-2 grid grid-cols-1 gap-1 text-xs sm:grid-cols-2">
        <PreviewField label="교회명" value={preview.church_name} />
        <PreviewField label="교단" value={denominationLabel(preview.denomination)} />
        <PreviewField label="지역" value={preview.region} />
        <PreviewField label="직분" value={POSITION_LABELS[preview.position]} />
        <PreviewField
          label="부서"
          value={preview.department !== null ? DEPARTMENT_LABELS[preview.department] : null}
        />
        <PreviewField
          label="고용형태"
          value={
            preview.employment_type !== null
              ? EMPLOYMENT_TYPE_LABELS[preview.employment_type]
              : null
          }
        />
        <PreviewField label="사례비" value={preview.stipend_note} />
        <PreviewField label="마감일" value={preview.deadline} />
      </dl>
      <p className="mt-2 border-t border-violet-100 pt-2 text-xs leading-relaxed text-gray-700">
        {preview.summary}
      </p>
    </div>
  );
}

export function RawPostingCard({ posting, saveState, onSave }: RawPostingCardProps) {
  const [structureState, setStructureState] = useState<StructureState>({ status: "idle" });

  const isLoginRequired =
    posting.raw_text === "" && posting.extra.detail_access === DETAIL_ACCESS_LOGIN_REQUIRED;
  const hasBody = posting.raw_text.length > 0;
  const preview =
    posting.raw_text.length > PREVIEW_MAX_CHARS
      ? `${posting.raw_text.slice(0, PREVIEW_MAX_CHARS)}…`
      : posting.raw_text;
  const isSaveDisabled = saveState !== "idle";
  const isStructureDisabled = !hasBody || structureState.status === "loading";

  const handleStructure = async () => {
    if (isStructureDisabled) return;
    setStructureState({ status: "loading" });
    try {
      const response = await fetch("/api/structure", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(posting),
      });
      if (!response.ok) {
        const body = (await response.json().catch(() => ({}))) as ApiErrorBody;
        throw new Error(body.error ?? `구조화 실패 (HTTP ${response.status})`);
      }
      const result = (await response.json()) as StructuredPreview;
      setStructureState({ status: "done", preview: result });
    } catch (error) {
      setStructureState({
        status: "error",
        message: error instanceof Error ? error.message : "구조화 실패",
      });
    }
  };

  return (
    <article className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <div className="flex flex-wrap items-center gap-2">
        <DenominationTag denomination={posting.default_denomination} />
        {isLoginRequired && <LoginRequiredBadge />}
      </div>

      <h3 className="mt-2 text-sm font-semibold leading-snug text-gray-900">{posting.title}</h3>

      <p className="mt-1 text-xs text-gray-500">
        {posting.posted_at ?? "날짜 미상"}
        {posting.author !== null && ` · ${posting.author}`}
        {posting.view_count !== null && ` · 조회 ${posting.view_count}`}
      </p>

      {hasBody ? (
        <details className="mt-3 group">
          <summary className="cursor-pointer list-none">
            <p className="whitespace-pre-line text-xs leading-relaxed text-gray-600 group-open:hidden">
              {preview}
            </p>
            <span className="mt-1 inline-block text-xs font-medium text-blue-600">
              <span className="group-open:hidden">본문 펼치기</span>
              <span className="hidden group-open:inline">본문 접기</span>
            </span>
          </summary>
          <p className="mt-2 whitespace-pre-line text-xs leading-relaxed text-gray-700">
            {posting.raw_text}
          </p>
        </details>
      ) : (
        <p className="mt-3 text-xs text-gray-400">본문 없음 — 목록 메타 정보만 수집됨</p>
      )}

      <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-gray-100 pt-3 text-xs text-gray-500">
        <a
          href={posting.post_url}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-blue-600 hover:underline"
        >
          원문 보기 ↗
        </a>
        <span>첨부 {posting.attachments.length}</span>
        <span>링크 {posting.links.length}</span>
        <button
          type="button"
          onClick={handleStructure}
          disabled={isStructureDisabled}
          title={hasBody ? undefined : "본문이 없어 구조화할 수 없습니다"}
          className="ml-auto rounded-md border border-violet-300 bg-white px-3 py-1.5 font-medium text-violet-700 transition hover:bg-violet-50 disabled:cursor-not-allowed disabled:border-gray-200 disabled:text-gray-300"
        >
          {structureState.status === "loading" ? "구조화 중…" : "구조화 미리보기"}
        </button>
        <button
          type="button"
          onClick={() => onSave(posting)}
          disabled={isSaveDisabled}
          className="rounded-md bg-gray-900 px-3 py-1.5 font-medium text-white transition hover:bg-gray-700 disabled:cursor-not-allowed disabled:bg-gray-300"
        >
          {SAVE_BUTTON_LABELS[saveState]}
        </button>
      </div>

      {structureState.status === "error" && (
        <p className="mt-3 rounded-md border border-red-200 bg-red-50 p-3 text-xs text-red-700">
          구조화 실패: {structureState.message}
        </p>
      )}
      {structureState.status === "done" && (
        <StructuredPreviewPanel preview={structureState.preview} />
      )}
    </article>
  );
}
