"use client";

import { useState } from "react";
import type { RawPosting, SourceInfo } from "@/lib/types";
import { postingKey } from "@/lib/types";
import { denominationLabel } from "@/lib/denominations";
import { ModeBadge } from "@/components/badges";
import { RawPostingCard, type SaveState } from "@/components/raw-posting-card";

const DEFAULT_LIMIT = 5;
const MIN_LIMIT = 1;
const MAX_LIMIT = 30;

interface CrawlConsoleProps {
  sources: SourceInfo[];
}

interface ApiErrorBody {
  error?: string;
}

export function CrawlConsole({ sources }: CrawlConsoleProps) {
  const [selectedSource, setSelectedSource] = useState<string>(sources[0]?.source_key ?? "");
  const [limit, setLimit] = useState<number>(DEFAULT_LIMIT);
  const [isCrawling, setIsCrawling] = useState(false);
  const [crawlError, setCrawlError] = useState<string | null>(null);
  const [postings, setPostings] = useState<RawPosting[] | null>(null);
  const [saveStates, setSaveStates] = useState<Record<string, SaveState>>({});

  const setSaveState = (key: string, state: SaveState) =>
    setSaveStates((prev) => ({ ...prev, [key]: state }));

  const handleCrawl = async () => {
    if (selectedSource === "" || isCrawling) return;
    setIsCrawling(true);
    setCrawlError(null);
    setPostings(null);
    try {
      const response = await fetch("/api/crawl", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ source: selectedSource, limit }),
      });
      if (!response.ok) {
        const body = (await response.json().catch(() => ({}))) as ApiErrorBody;
        throw new Error(body.error ?? `크롤 실패 (HTTP ${response.status})`);
      }
      const result = (await response.json()) as RawPosting[];
      setPostings(result);
      setSaveStates({});
    } catch (error) {
      setCrawlError(error instanceof Error ? error.message : "크롤 실패");
    } finally {
      setIsCrawling(false);
    }
  };

  const handleSave = async (posting: RawPosting) => {
    const key = postingKey(posting);
    setSaveState(key, "saving");
    try {
      const response = await fetch("/api/save", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(posting),
      });
      if (!response.ok) {
        const body = (await response.json().catch(() => ({}))) as ApiErrorBody;
        throw new Error(body.error ?? `저장 실패 (HTTP ${response.status})`);
      }
      const result = (await response.json()) as { status: "saved" | "duplicate" };
      setSaveState(key, result.status === "saved" ? "saved" : "duplicate");
    } catch (error) {
      setSaveState(key, "idle");
      alert(error instanceof Error ? error.message : "저장 실패");
    }
  };

  return (
    <div className="flex flex-col gap-6 lg:flex-row">
      {/* 좌측: 소스 선택 + 실행 */}
      <aside className="w-full shrink-0 lg:w-72">
        <h2 className="text-sm font-semibold text-gray-900">크롤 소스</h2>
        <ul className="mt-2 space-y-1.5">
          {sources.map((source) => {
            const isSelected = source.source_key === selectedSource;
            return (
              <li key={source.source_key}>
                <button
                  type="button"
                  onClick={() => setSelectedSource(source.source_key)}
                  className={`w-full rounded-lg border p-3 text-left transition ${
                    isSelected
                      ? "border-gray-900 bg-gray-900 text-white"
                      : "border-gray-200 bg-white hover:border-gray-400"
                  }`}
                >
                  <span className="block text-sm font-medium leading-snug">
                    {source.board_name}
                  </span>
                  <span
                    className={`mt-1 flex items-center gap-2 text-xs ${
                      isSelected ? "text-gray-300" : "text-gray-500"
                    }`}
                  >
                    {denominationLabel(source.default_denomination)}
                    <ModeBadge mode={source.crawl_mode} />
                  </span>
                </button>
              </li>
            );
          })}
        </ul>

        <div className="mt-4 flex items-end gap-2">
          <label className="flex-1 text-xs font-medium text-gray-700">
            limit (건수)
            <input
              type="number"
              min={MIN_LIMIT}
              max={MAX_LIMIT}
              value={limit}
              onChange={(event) => setLimit(Number(event.target.value))}
              className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-gray-900 focus:outline-none"
            />
          </label>
          <button
            type="button"
            onClick={handleCrawl}
            disabled={isCrawling || selectedSource === ""}
            className="rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:bg-gray-300"
          >
            {isCrawling ? "크롤 중…" : "크롤 실행"}
          </button>
        </div>
      </aside>

      {/* 우측: raw 결과 */}
      <section className="min-w-0 flex-1">
        <h2 className="text-sm font-semibold text-gray-900">
          Raw 결과{postings !== null && ` (${postings.length}건)`}
        </h2>

        {isCrawling && (
          <p className="mt-3 rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-500">
            크롤 실행 중입니다… 소스 응답 속도에 따라 수십 초 걸릴 수 있습니다.
          </p>
        )}
        {crawlError !== null && (
          <p className="mt-3 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {crawlError}
          </p>
        )}
        {!isCrawling && crawlError === null && postings === null && (
          <p className="mt-3 rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-400">
            소스를 선택하고 크롤을 실행하면 raw 결과가 여기에 표시됩니다.
          </p>
        )}
        {postings !== null && postings.length === 0 && (
          <p className="mt-3 rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-400">
            수집된 공고가 없습니다.
          </p>
        )}

        {postings !== null && postings.length > 0 && (
          <div className="mt-3 space-y-3">
            {postings.map((posting) => {
              const key = postingKey(posting);
              return (
                <RawPostingCard
                  key={key}
                  posting={posting}
                  saveState={saveStates[key] ?? "idle"}
                  onSave={handleSave}
                />
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
